<?php
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: admin_login.php");
    exit();
}
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST['id_number'];
    $course = $_POST['course'];
    $score = $_POST['score'];

    $stmt = $conn->prepare("INSERT INTO scores (id_number, course, score) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $id, $course, $score);
    $stmt->execute();
    echo "<script>alert('Score added successfully');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Add Score</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Admin: Add Student Score</h2>
    <form method="POST" action="admin.php">
        <label>ID Number:</label><br>
        <input type="text" name="id_number" required><br><br>
        <label>Course:</label><br>
        <input type="text" name="course" required><br><br>
        <label>Score:</label><br>
        <input type="number" name="score" required><br><br>
        <button type="submit">Add Score</button>
    </form>
    <br><a href="admin_logout.php">Logout</a>
</body>
</html>
