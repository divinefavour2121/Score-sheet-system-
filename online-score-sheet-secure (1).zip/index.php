<!DOCTYPE html>
<html>
<head>
    <title>Welcome - Online Score Sheet</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Welcome to the Online Score Sheet System</h2>
    <p>Please select your portal:</p>
    <div>
        <a href="login.php"><button>Student Login</button></a>
        <a href="admin_login.php"><button>Admin Login</button></a>
    </div>
</body>
</html>
